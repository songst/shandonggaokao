const state = {
  categoryId: "all",
  index: 0,
  showAnswer: false,
  showAnalysis: false,
  favoritesOnly: false,
  favorites: new Set(JSON.parse(localStorage.getItem("qut-favorites") || "[]")),
  seen: new Set(JSON.parse(localStorage.getItem("qut-seen") || "[]"))
};

const els = {
  categoryList: document.querySelector("#categoryList"),
  progressText: document.querySelector("#progressText"),
  progressFill: document.querySelector("#progressFill"),
  favoriteCount: document.querySelector("#favoriteCount"),
  seenCount: document.querySelector("#seenCount"),
  modeText: document.querySelector("#modeText"),
  pageTitle: document.querySelector("#pageTitle"),
  shuffleBtn: document.querySelector("#shuffleBtn"),
  favoritesOnlyBtn: document.querySelector("#favoritesOnlyBtn"),
  questionCategory: document.querySelector("#questionCategory"),
  questionIndex: document.querySelector("#questionIndex"),
  questionText: document.querySelector("#questionText"),
  showAnswerBtn: document.querySelector("#showAnswerBtn"),
  answerSection: document.querySelector("#answerSection"),
  answerText: document.querySelector("#answerText"),
  analysisSection: document.querySelector("#analysisSection"),
  focusList: document.querySelector("#focusList"),
  followList: document.querySelector("#followList"),
  analysisBtn: document.querySelector("#analysisBtn"),
  favoriteBtn: document.querySelector("#favoriteBtn"),
  prevBtn: document.querySelector("#prevBtn"),
  nextBtn: document.querySelector("#nextBtn")
};

function getPool() {
  let questions = window.INTERVIEW_QUESTIONS.slice(0, 120);
  if (state.categoryId !== "all") {
    questions = window.INTERVIEW_QUESTIONS.filter((question) => question.categoryId === state.categoryId);
  }
  if (state.favoritesOnly) {
    questions = questions.filter((question) => state.favorites.has(question.id));
  }
  return questions;
}

function getCurrentQuestion() {
  const pool = getPool();
  if (!pool.length) return null;
  state.index = Math.max(0, Math.min(state.index, pool.length - 1));
  return pool[state.index];
}

function saveSets() {
  localStorage.setItem("qut-favorites", JSON.stringify([...state.favorites]));
  localStorage.setItem("qut-seen", JSON.stringify([...state.seen]));
}

function resetReveal() {
  state.showAnswer = false;
  state.showAnalysis = false;
}

function renderCategories() {
  const allCount = 120;
  const buttons = [
    { id: "all", label: `随机模拟（全部）`, icon: "🎲", count: allCount },
    ...window.INTERVIEW_CATEGORIES.map((category) => ({
      id: category.id,
      label: category.label,
      icon: category.icon,
      count: category.count
    }))
  ];

  els.categoryList.innerHTML = buttons
    .map(
      (item) => `
        <button class="category-button ${state.categoryId === item.id ? "active" : ""}" type="button" data-category="${item.id}">
          <span class="category-name">${item.icon} ${item.label.replace(/（.*$/, "")}</span>
          <span class="category-count">${item.count}题</span>
        </button>
      `
    )
    .join("");
}

function renderEmpty() {
  els.questionCategory.textContent = "收藏夹";
  els.questionIndex.textContent = "暂无题目";
  els.questionText.textContent = "当前分类下还没有收藏题目。";
  els.answerSection.classList.add("hidden");
  els.analysisSection.classList.add("hidden");
  els.showAnswerBtn.disabled = true;
  els.analysisBtn.disabled = true;
  els.favoriteBtn.disabled = true;
  els.prevBtn.disabled = true;
  els.nextBtn.disabled = true;
}

function renderQuestion() {
  const pool = getPool();
  const question = getCurrentQuestion();
  renderCategories();

  els.favoriteCount.textContent = state.favorites.size;
  els.seenCount.textContent = state.seen.size;
  els.favoritesOnlyBtn.classList.toggle("active", state.favoritesOnly);
  els.favoritesOnlyBtn.textContent = state.favoritesOnly ? "显示全部" : "只看收藏";

  if (!question) {
    renderEmpty();
    return;
  }

  const categoryLabel =
    state.categoryId === "all"
      ? "青科通用"
      : window.INTERVIEW_CATEGORIES.find((category) => category.id === state.categoryId)?.name || "青科通用";

  els.modeText.textContent = state.favoritesOnly ? "收藏练习" : "练习页面";
  els.pageTitle.textContent = state.categoryId === "all" ? "一次显示一道题" : `${categoryLabel}专项练习`;
  els.questionCategory.textContent = categoryLabel;
  els.questionIndex.textContent = `第 ${state.index + 1} / ${pool.length} 题`;
  els.progressText.textContent = `${state.index + 1} / ${pool.length}`;
  els.progressFill.style.width = `${((state.index + 1) / pool.length) * 100}%`;
  els.questionText.textContent = question.title;
  els.answerText.textContent = question.answer;
  els.focusList.innerHTML = question.focus.map((item) => `<li>${item}</li>`).join("");
  els.followList.innerHTML = question.followUps.map((item) => `<li>${item}</li>`).join("");

  els.answerSection.classList.toggle("hidden", !state.showAnswer);
  els.analysisSection.classList.toggle("hidden", !state.showAnalysis);
  els.showAnswerBtn.textContent = state.showAnswer ? "隐藏参考答案" : "显示参考答案";
  els.analysisBtn.textContent = state.showAnalysis ? "收起解析" : "查看解析";
  els.analysisBtn.classList.toggle("active", state.showAnalysis);
  els.favoriteBtn.textContent = state.favorites.has(question.id) ? "取消收藏" : "收藏本题";
  els.favoriteBtn.classList.toggle("active", state.favorites.has(question.id));

  els.showAnswerBtn.disabled = false;
  els.analysisBtn.disabled = false;
  els.favoriteBtn.disabled = false;
  els.prevBtn.disabled = state.index === 0;
  els.nextBtn.disabled = state.index === pool.length - 1;
}

els.categoryList.addEventListener("click", (event) => {
  const button = event.target.closest("[data-category]");
  if (!button) return;
  state.categoryId = button.dataset.category;
  state.index = 0;
  resetReveal();
  renderQuestion();
});

els.showAnswerBtn.addEventListener("click", () => {
  const question = getCurrentQuestion();
  if (!question) return;
  state.showAnswer = !state.showAnswer;
  if (state.showAnswer) {
    state.seen.add(question.id);
    saveSets();
  }
  renderQuestion();
});

els.analysisBtn.addEventListener("click", () => {
  state.showAnalysis = !state.showAnalysis;
  if (state.showAnalysis) state.showAnswer = true;
  renderQuestion();
});

els.favoriteBtn.addEventListener("click", () => {
  const question = getCurrentQuestion();
  if (!question) return;
  if (state.favorites.has(question.id)) {
    state.favorites.delete(question.id);
  } else {
    state.favorites.add(question.id);
  }
  saveSets();
  renderQuestion();
});

els.prevBtn.addEventListener("click", () => {
  state.index -= 1;
  resetReveal();
  renderQuestion();
});

els.nextBtn.addEventListener("click", () => {
  state.index += 1;
  resetReveal();
  renderQuestion();
});

els.shuffleBtn.addEventListener("click", () => {
  const pool = getPool();
  if (!pool.length) return;
  state.index = Math.floor(Math.random() * pool.length);
  resetReveal();
  renderQuestion();
});

els.favoritesOnlyBtn.addEventListener("click", () => {
  state.favoritesOnly = !state.favoritesOnly;
  state.index = 0;
  resetReveal();
  renderQuestion();
});

renderQuestion();
